# MotionLab Studio

Editor web estático de dibujo, animación 2D y motion graphics. Está preparado para publicarse en GitHub Pages y no necesita servidor, Python, Node.js ni una cuenta para utilizarse.

## Abrir la aplicación

- **En GitHub Pages:** abre la URL publicada por tu repositorio.
- **En local:** los módulos JavaScript requieren un servidor estático; no abras `index.html` con doble clic (`file://`). En un ordenador, utiliza una extensión de servidor estático. En Chromebook, la opción más sencilla sin instalar herramientas es publicar la carpeta en GitHub Pages y abrir su URL.

La aplicación guarda automáticamente el proyecto activo en IndexedDB del navegador. El almacenamiento es local al navegador/dispositivo; exporta copias JSON o ZIP para no depender de ese almacenamiento.

## Publicar en GitHub Pages

1. Descomprime `MotionLab-Studio.zip`.
2. Sube el contenido de la carpeta al repositorio, en la rama `main` (incluida la carpeta oculta `.github`).
3. En GitHub entra en **Settings → Pages**.
4. En **Build and deployment → Source**, selecciona **GitHub Actions**.
5. Haz push a `main`. El workflow `.github/workflows/deploy.yml` prepara los archivos estáticos y los publica.

El workflow puede desempaquetar ZIPs adicionales puestos dentro de `distribution/` durante el despliegue. GitHub Pages no descomprime ZIP automáticamente al visitar la página.

## Funciones implementadas en esta versión

### Dibujo (MotionLab Draw)

- Lápiz, pincel, rotulador, tinta, pincel suave, aerógrafo, borrador, línea, rectángulo, elipse, relleno y cuentagotas.
- Tamaño, opacidad, dureza, fluidez, color, paletas rápidas y estabilización.
- Presión del lápiz cuando el navegador recibe eventos de presión (`PointerEvent` con `pointerType: pen`).
- Capas de dibujo separadas; cada capa es un objeto de escena y guarda cels por fotograma.
- Limpiar y duplicar cels; onion skin de fotogramas cercanos; navegación fotograma a fotograma.

### Objetos y animación

- Texto editable, rectángulos, círculos, triángulos, líneas e imágenes importadas.
- Selección, movimiento con ratón, duplicación, borrado, orden de capas, visibilidad y bloqueo.
- Propiedades de posición, tamaño, rotación, opacidad y color.
- Keyframes para X, Y, ancho, alto, rotación y opacidad, con interpolación lineal y easing básico.
- Escenas independientes con fondo y duración propios.
- Reproducción, FPS, timeline con keyframes arrastrables y fotogramas de dibujo.

### Proyectos y exportación

- Guardado automático en IndexedDB (con respaldo en localStorage si IndexedDB no está disponible).
- Deshacer/rehacer, importar proyecto JSON/ZIP y exportar JSON/ZIP.
- Exportación de vídeo WebM cuando MediaRecorder y `canvas.captureStream()` están disponibles.
- Exportación de secuencia PNG empaquetada en ZIP.
- Proyecto de ejemplo editable en `examples/primer-proyecto.motionlab.json`.

## Controles

| Acción | Control |
|---|---|
| Deshacer / rehacer | `Ctrl+Z` / `Ctrl+Y` |
| Copiar / pegar objeto | `Ctrl+C` / `Ctrl+V` |
| Eliminar objeto | `Supr` o `Backspace` |
| Modo objetos | `V` |
| Modo dibujo / pincel | `B` |
| Borrador | `E` |
| Crear texto | `T` |
| Fotograma anterior / siguiente | `←` / `→` |
| Cambiar zoom del lienzo | `Ctrl` + rueda del ratón |

## Límites conocidos de esta entrega

Esta versión es una base funcional ampliable, no un sustituto completo de Photoshop, Procreate o After Effects. Aún no incluye editor de curvas Bézier visual, selección poligonal/lazo con transformación de píxeles, grupos de capas avanzados, audio multipista, interpolación automática de dibujos, filtros complejos, máscaras ni exportación MP4/GIF nativa. WebM depende de las capacidades del navegador. La biblioteca JSZip se carga de forma opcional desde jsDelivr para las operaciones ZIP y las secuencias PNG; JSON y la edición principal funcionan sin ella.

La presión depende del dispositivo, del navegador y del lápiz: un ratón no proporciona presión real. Los archivos e imágenes se incrustan como datos en el proyecto para mantenerlos al importar/exportar.

## Estructura

```text
MotionLab-Studio/
├── index.html
├── manifest.json
├── README.md
├── assets/
│   └── icon.svg
├── css/
│   └── main.css
├── js/
│   ├── app.js
│   ├── model.js
│   ├── renderer.js
│   ├── drawing.js
│   ├── storage.js
│   └── exporter.js
├── examples/
│   └── primer-proyecto.motionlab.json
└── .github/workflows/deploy.yml
```

## Privacidad

Los proyectos se guardan localmente en el navegador. No se envían a un servidor de MotionLab. Las funciones ZIP utilizan JSZip desde jsDelivr; no se transmiten los datos del proyecto a ese proveedor.
