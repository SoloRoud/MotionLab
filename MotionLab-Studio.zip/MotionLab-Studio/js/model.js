export const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
export const clamp = (v,min,max)=>Math.min(max,Math.max(min,v));
export function makeProject(){
  const scene=makeScene('Escena 1');
  return {version:1,name:'Mi primer proyecto',width:1920,height:1080,fps:30,duration:5,scenes:[scene],activeSceneId:scene.id,createdAt:Date.now(),updatedAt:Date.now()};
}
export function makeScene(name='Escena nueva') { return {id:uid(),name,duration:5,background:'#ffffff',objects:[]}; }
export function currentScene(project){return project.scenes.find(s=>s.id===project.activeSceneId)||project.scenes[0];}
export function makeShape(type='rect',x=650,y=350){return {id:uid(),type,name:type==='text'?'Texto':type==='ellipse'?'Círculo':type==='line'?'Línea':'Rectángulo',x,y,w:type==='text'?500:280,h:type==='text'?100:180,rotation:0,opacity:1,fill:type==='text'?'#20242e':'#f47751',stroke:'#242833',strokeWidth:type==='line'?8:0,text:type==='text'?'Escribe aquí':'',fontSize:72,fontFamily:'Manrope',bold:true,visible:true,locked:false,keyframes:{},createdAt:Date.now()};}
export function makeDrawingLayer(name='Capa de dibujo',width=1920,height=1080){return {id:uid(),type:'drawing',name,x:0,y:0,w:width,h:height,rotation:0,opacity:1,visible:true,locked:false,cels:{},keyframes:{},createdAt:Date.now()};}
export function addKeyframe(object,property,frame,value){
  object.keyframes ||= {}; object.keyframes[property] ||= [];
  const arr=object.keyframes[property]; const existing=arr.find(k=>k.frame===frame);
  if(existing) existing.value=value; else arr.push({frame,value,ease:'linear'});
  arr.sort((a,b)=>a.frame-b.frame);
}
export function evaluate(object,property,frame,fallback){
  const keys=object.keyframes?.[property]; if(!keys?.length)return object[property]??fallback;
  if(frame<=keys[0].frame)return keys[0].value;
  if(frame>=keys[keys.length-1].frame)return keys[keys.length-1].value;
  let a=keys[0],b=keys[keys.length-1];
  for(let i=0;i<keys.length-1;i++){if(frame>=keys[i].frame&&frame<=keys[i+1].frame){a=keys[i];b=keys[i+1];break;}}
  let t=(frame-a.frame)/(b.frame-a.frame); if(a.ease==='ease-in')t=t*t; else if(a.ease==='ease-out')t=1-(1-t)*(1-t); else if(a.ease==='ease-in-out')t=t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
  return typeof a.value==='number'&&typeof b.value==='number'?a.value+(b.value-a.value)*t:(t<1?a.value:b.value);
}
export function duplicateObject(obj){const copy=JSON.parse(JSON.stringify(obj));copy.id=uid();copy.name=`${obj.name||'Objeto'} copia`;copy.x=(copy.x||0)+30;copy.y=(copy.y||0)+30;return copy;}
