import {evaluate} from './model.js';
const imageCache=new Map();
function imageFor(src){if(!src)return null;let img=imageCache.get(src);if(img)return img;img=new Image();img.onload=()=>{window.dispatchEvent(new Event('motionlab-render'));};img.src=src;imageCache.set(src,img);return img;}
export function objectAtFrame(obj,frame){return {x:evaluate(obj,'x',frame,obj.x),y:evaluate(obj,'y',frame,obj.y),w:evaluate(obj,'w',frame,obj.w),h:evaluate(obj,'h',frame,obj.h),rotation:evaluate(obj,'rotation',frame,obj.rotation||0),opacity:evaluate(obj,'opacity',frame,obj.opacity??1),fill:evaluate(obj,'fill',frame,obj.fill)};}
function drawObject(ctx,obj,frame,project){
  if(obj.visible===false)return;
  const p=objectAtFrame(obj,frame),x=p.x,y=p.y,w=p.w,h=p.h;
  ctx.save();ctx.globalAlpha=Math.max(0,Math.min(1,p.opacity??1));ctx.translate(x+w/2,y+h/2);ctx.rotate((p.rotation||0)*Math.PI/180);ctx.translate(-w/2,-h/2);
  if(obj.type==='drawing'){
    const live=window.__motionlabCanvasCache?.get(`${obj.id}:${frame}`);
    if(live){ctx.drawImage(live,0,0,live.width,live.height,0,0,w,h);ctx.restore();return;}
    const exact=obj.cels?.[String(frame)];
    const prevKeys=Object.keys(obj.cels||{}).map(Number).filter(n=>n<frame).sort((a,b)=>b-a);
    const held=exact||(!obj.holdBlank&&prevKeys.length?obj.cels[String(prevKeys[0])]:null);
    if(held){const im=imageFor(held);if(im?.complete&&im.naturalWidth)ctx.drawImage(im,0,0,im.naturalWidth,im.naturalHeight,0,0,w,h);}
  }else if(obj.type==='image'){
    const im=imageFor(obj.src);if(im?.complete&&im.naturalWidth)ctx.drawImage(im,0,0,w,h);else{ctx.fillStyle='#ddd';ctx.fillRect(0,0,w,h);}
  }else if(obj.type==='text'){
    ctx.fillStyle=p.fill||'#20242e';ctx.textAlign=obj.align||'left';ctx.textBaseline='middle';ctx.font=`${obj.bold?'700':'400'} ${obj.fontSize||64}px ${obj.fontFamily||'sans-serif'}`;
    const lines=String(obj.text||'').split('\n'),lineH=(obj.fontSize||64)*1.2;lines.forEach((line,i)=>ctx.fillText(line,0,(i-(lines.length-1)/2)*lineH,w));
  }else{
    ctx.fillStyle=p.fill||'transparent';ctx.strokeStyle=obj.stroke||'#242833';ctx.lineWidth=obj.strokeWidth||0;
    if(obj.type==='ellipse'){ctx.beginPath();ctx.ellipse(w/2,h/2,w/2,h/2,0,0,Math.PI*2);ctx.fill();if(ctx.lineWidth)ctx.stroke();}
    else if(obj.type==='line'){ctx.beginPath();ctx.moveTo(0,h/2);ctx.lineTo(w,h/2);ctx.strokeStyle=obj.fill||obj.stroke;ctx.lineWidth=obj.strokeWidth||8;ctx.stroke();}
    else if(obj.type==='triangle'){ctx.beginPath();ctx.moveTo(w/2,0);ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();ctx.fill();if(ctx.lineWidth)ctx.stroke();}
    else {const r=Math.min(obj.radius||0,24);ctx.beginPath();if(ctx.roundRect)ctx.roundRect(0,0,w,h,r);else ctx.rect(0,0,w,h);ctx.fill();if(ctx.lineWidth)ctx.stroke();}
  }
  ctx.restore();
}
export function renderScene(ctx,project,scene,frame=0,{onion=false,selectedId=null,clear=true}={}){
  if(clear)ctx.clearRect(0,0,project.width,project.height);
  ctx.fillStyle=scene.background||'#fff';ctx.fillRect(0,0,project.width,project.height);
  if(onion){
    for(const obj of scene.objects){if(obj.type!=='drawing'||obj.visible===false)continue;
      const keys=Object.keys(obj.cels||{}).map(Number).sort((a,b)=>a-b),prev=keys.filter(n=>n<frame).pop(),next=keys.find(n=>n>frame);
      const p=objectAtFrame(obj,frame);ctx.save();ctx.globalAlpha=.16;ctx.translate(p.x,p.y);ctx.scale(p.w/project.width,p.h/project.height);
      for(const [k,tint] of [[prev,'#ee5965'],[next,'#4c8ff5']]){if(k===undefined)continue;const im=imageFor(obj.cels[String(k)]);if(im?.complete&&im.naturalWidth){ctx.save();ctx.globalAlpha=.17;ctx.drawImage(im,0,0);ctx.globalCompositeOperation='source-atop';ctx.fillStyle=tint;ctx.fillRect(0,0,project.width,project.height);ctx.restore();}}
      ctx.restore();
    }
  }
  for(const obj of scene.objects)drawObject(ctx,obj,frame,project);
  if(selectedId){const obj=scene.objects.find(o=>o.id===selectedId);if(obj){const p=objectAtFrame(obj,frame);ctx.save();ctx.strokeStyle='#f47751';ctx.lineWidth=2;ctx.setLineDash([7,5]);ctx.strokeRect(p.x,p.y,p.w,p.h);ctx.setLineDash([]);ctx.fillStyle='#fff';ctx.strokeStyle='#f47751';for(const [x,y] of [[p.x,p.y],[p.x+p.w,p.y],[p.x,p.y+p.h],[p.x+p.w,p.y+p.h]]){ctx.beginPath();ctx.rect(x-5,y-5,10,10);ctx.fill();ctx.stroke();}ctx.restore();}}
}
export function hitTest(scene,x,y,frame){for(let i=scene.objects.length-1;i>=0;i--){const o=scene.objects[i];if(o.visible===false)continue;const p=objectAtFrame(o,frame);if(x<p.x||x>p.x+p.w||y<p.y||y>p.y+p.h)continue;if(o.type==='drawing'){const src=o.cels?.[String(frame)]||Object.keys(o.cels||{}).map(Number).filter(n=>n<frame).sort((a,b)=>b-a).map(n=>o.cels[String(n)])[0];const live=window.__motionlabCanvasCache?.get(`${o.id}:${frame}`);let sampleCanvas=live;if(!sampleCanvas&&src){const im=imageFor(src);if(im?.complete&&im.naturalWidth){const key=`pick:${src}`;sampleCanvas=imageCache.get(key);if(!sampleCanvas){sampleCanvas=document.createElement('canvas');sampleCanvas.width=im.naturalWidth;sampleCanvas.height=im.naturalHeight;sampleCanvas.getContext('2d').drawImage(im,0,0);imageCache.set(key,sampleCanvas);}}}if(!sampleCanvas)continue;const sx=Math.max(0,Math.min(sampleCanvas.width-1,Math.floor((x-p.x)/p.w*sampleCanvas.width))),sy=Math.max(0,Math.min(sampleCanvas.height-1,Math.floor((y-p.y)/p.h*sampleCanvas.height)));try{if(sampleCanvas.getContext('2d',{willReadFrequently:true}).getImageData(sx,sy,1,1).data[3]<12)continue;}catch{continue;}}return o;}return null;}
