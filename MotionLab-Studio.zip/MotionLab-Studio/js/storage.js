const DB_NAME='motionlab-studio-db', STORE='projects';
let dbPromise;
function openDB(){
  if(dbPromise)return dbPromise;
  dbPromise=new Promise((resolve,reject)=>{
    if(!('indexedDB' in window)){reject(new Error('IndexedDB no está disponible'));return;}
    const req=indexedDB.open(DB_NAME,1);
    req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'id'});};
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
  });return dbPromise;
}
export async function saveProject(project){
  try{const db=await openDB();const snapshot=JSON.parse(JSON.stringify(project));snapshot.id='current';snapshot.updatedAt=Date.now();await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(snapshot);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});return true;}
  catch(err){try{localStorage.setItem('motionlab-project',JSON.stringify(project));return true;}catch(e){console.warn(err,e);return false;}}
}
export async function loadProject(){
  try{const db=await openDB();const result=await new Promise((resolve,reject)=>{const req=db.transaction(STORE,'readonly').objectStore(STORE).get('current');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});if(result){delete result.id;return result;}}
  catch(err){console.warn('IndexedDB no disponible; se probará el respaldo local.',err);}
  try{return JSON.parse(localStorage.getItem('motionlab-project')||'null');}catch{return null;}
}
